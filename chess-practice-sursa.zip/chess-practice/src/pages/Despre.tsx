import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

const Despre = () => (
  <div className="min-h-dvh flex flex-col">
    <SiteHeader />
    <main className="flex-1 px-6 md:px-12 py-12 max-w-[900px] mx-auto w-full">
      <span className="text-[10px] uppercase tracking-[0.3em] text-ember font-mono">Documentație</span>
      <h1 className="font-serif text-5xl md:text-6xl text-tungsten mt-3">Despre proiect</h1>

      <div className="prose prose-invert max-w-none mt-12 space-y-8 text-tungsten-muted leading-relaxed">
        <p className="text-lg text-tungsten">
          <span className="font-serif italic text-2xl">Chess Practice</span> este o aplicație web dedicată
          antrenamentului la șah, dezvoltată ca proiect de atestat la informatică pentru clasa a XII-a.
        </p>

        <section>
          <h2 className="font-serif text-3xl text-tungsten mb-4">Funcționalități</h2>
          <ul className="space-y-3 list-none pl-0">
            <li className="flex gap-4 border-l-2 border-ember/40 pl-4">
              <span className="font-mono text-xs uppercase tracking-widest text-ember pt-1">01</span>
              <div>
                <strong className="text-tungsten">Joc împotriva motorului Stockfish</strong> pe trei niveluri
                de dificultate: începător, intermediar și avansat.
              </div>
            </li>
            <li className="flex gap-4 border-l-2 border-ember/40 pl-4">
              <span className="font-mono text-xs uppercase tracking-widest text-ember pt-1">02</span>
              <div>
                <strong className="text-tungsten">Arhivă de puzzle-uri tactice</strong> — mat în 1, mat în 2,
                furculițe, capcane de deschidere și finaluri de pioni.
              </div>
            </li>
            <li className="flex gap-4 border-l-2 border-ember/40 pl-4">
              <span className="font-mono text-xs uppercase tracking-widest text-ember pt-1">03</span>
              <div>
                <strong className="text-tungsten">Funcționare 100% offline</strong> — motorul Stockfish rulează
                local în browser, fără apeluri către servere externe.
              </div>
            </li>
          </ul>
        </section>

        <section>
          <h2 className="font-serif text-3xl text-tungsten mb-4">Tehnologii utilizate</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {[
              ["React 18", "Bibliotecă UI"],
              ["TypeScript", "Tipare statice"],
              ["Vite", "Build tool"],
              ["Tailwind CSS", "Stilizare"],
              ["chess.js", "Regulile jocului"],
              ["Stockfish.js", "Motor de șah"],
              ["react-chessboard", "Componentă tablă"],
              ["React Router", "Navigare"],
            ].map(([n, d]) => (
              <div key={n} className="bg-mahogany-900 border border-wood/20 p-4">
                <div className="font-serif text-tungsten">{n}</div>
                <div className="text-xs text-wood-light font-mono uppercase tracking-widest mt-1">{d}</div>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className="font-serif text-3xl text-tungsten mb-4">Cum funcționează motorul</h2>
          <p>
            Stockfish este unul dintre cele mai puternice motoare de șah open-source din lume, scris în C++ și
            compilat în JavaScript prin Emscripten. Rulează ca <em className="text-tungsten">Web Worker</em>,
            într-un fir de execuție separat, comunicând cu interfața prin protocolul UCI (Universal Chess Interface).
          </p>
          <p>
            Dificultatea este controlată prin opțiunea <code className="font-mono text-ember">Skill Level</code>{" "}
            (0–20) și prin limitarea adâncimii de căutare și a timpului de gândire.
          </p>
        </section>
      </div>
    </main>
    <SiteFooter />
  </div>
);

export default Despre;
